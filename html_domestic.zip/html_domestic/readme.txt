
READ ME
navigate to the file named domestic.htm inside the domestic directory and open this in your browser.